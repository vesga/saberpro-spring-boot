
package com.uts.saberpro.repository;

import com.uts.saberpro.model.ExamenResultado;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ExamenResultadoRepository extends JpaRepository<ExamenResultado, Long> {
    List<ExamenResultado> findByAlumnoIdOrderByFechaDesc(Long alumnoId);
    List<ExamenResultado> findByTipoExamen(String tipoExamen);
}
