
package com.uts.saberpro.repository;

import com.uts.saberpro.model.Incentivo;
import org.springframework.data.jpa.repository.JpaRepository;
public interface IncentivoRepository extends JpaRepository<Incentivo, Long> {
    Incentivo findByExamenResultadoId(Long examenResultadoId);
}
