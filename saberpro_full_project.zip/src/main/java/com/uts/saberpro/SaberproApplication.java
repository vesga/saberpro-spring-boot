package com.uts.saberpro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaberproApplication {
    public static void main(String[] args) {
        SpringApplication.run(SaberproApplication.class, args);
    }
}
