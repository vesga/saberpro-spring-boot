
package com.uts.saberpro.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "incentivo")
public class Incentivo {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "examen_resultado_id")
    private ExamenResultado examenResultado;
    private String tipoIncentivo;
    @Column(columnDefinition = "TEXT")
    private String descripcion;
    private Integer porcentajeBeca;
    private Boolean exencionInforme;
    private Double notaExigida;
    private LocalDate vigenciaInicio;
    private LocalDate vigenciaFin;
    private LocalDateTime creadoEn;

    @PrePersist public void prePersist(){ creadoEn = LocalDateTime.now(); }

    public Long getId(){return id;}
    public ExamenResultado getExamenResultado(){return examenResultado;}
    public void setExamenResultado(ExamenResultado examenResultado){this.examenResultado = examenResultado;}
    public String getTipoIncentivo(){return tipoIncentivo;}
    public void setTipoIncentivo(String tipoIncentivo){this.tipoIncentivo = tipoIncentivo;}
    public String getDescripcion(){return descripcion;}
    public void setDescripcion(String descripcion){this.descripcion = descripcion;}
    public Integer getPorcentajeBeca(){return porcentajeBeca;}
    public void setPorcentajeBeca(Integer porcentajeBeca){this.porcentajeBeca = porcentajeBeca;}
    public Boolean getExencionInforme(){return exencionInforme;}
    public void setExencionInforme(Boolean exencionInforme){this.exencionInforme = exencionInforme;}
    public Double getNotaExigida(){return notaExigida;}
    public void setNotaExigida(Double notaExigida){this.notaExigida = notaExigida;}
    public LocalDate getVigenciaInicio(){return vigenciaInicio;}
    public void setVigenciaInicio(LocalDate vigenciaInicio){this.vigenciaInicio = vigenciaInicio;}
    public LocalDate getVigenciaFin(){return vigenciaFin;}
    public void setVigenciaFin(LocalDate vigenciaFin){this.vigenciaFin = vigenciaFin;}
    public LocalDateTime getCreadoEn(){return creadoEn;}
}
