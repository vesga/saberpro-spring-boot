
package com.uts.saberpro.controller;

import com.uts.saberpro.model.Alumno;
import com.uts.saberpro.repository.AlumnoRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/alumnos")
public class AlumnoController {
    private final AlumnoRepository alumnoRepository;

    public AlumnoController(AlumnoRepository alumnoRepository){
        this.alumnoRepository = alumnoRepository;
    }

    @GetMapping
    public String list(Model model){
        List<Alumno> alumnos = alumnoRepository.findAll();
        model.addAttribute("alumnos", alumnos);
        return "alumnos/list";
    }

    @GetMapping("/nuevo")
    public String nuevoForm(Model model){
        model.addAttribute("alumno", new Alumno());
        return "alumnos/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Alumno alumno, Model model){
        if (alumno.getIdentificacion() != null) {
            var existing = alumnoRepository.findByIdentificacion(alumno.getIdentificacion());
            if (existing.isPresent()) {
                model.addAttribute("error", "Identificación ya existe");
                return "alumnos/form";
            }
        }
        alumnoRepository.save(alumno);
        return "redirect:/alumnos";
    }
}
